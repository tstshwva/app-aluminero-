import * as Network from "expo-network";
import { canAttemptNetwork } from "./networkState";
import { createOfflineStore } from "./offlineStorage";
import { withOfflineData } from "./offlineClient";
import { useAppUpdates } from "./useAppUpdates";
import { UpdateStatus } from "./UpdateStatus";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  AppState,
  Image,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { Text, TextInput, useAppFonts } from "./Typography";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { createFirebaseClient } from "@aluformix/client";
import { createSessionStorage } from "./storage";
import BusinessApp from "./BusinessApp";
import { loadDarkMode, saveDarkMode } from "./preferences";
import { createDemoClient } from "./demoClient";
import "./dialogs";
import { getAssistantAppCheckToken } from "./assistantAppCheck";
import { FieldIssue, formError, Notice, validationStyles } from "./Feedback";

// Modo demostración: solo con EXPO_PUBLIC_DEMO=1 en el .env de la app.
// Usa datos de ejemplo en memoria y no se conecta a la API.
const demo = process.env.EXPO_PUBLIC_DEMO === "1";

// En el navegador, la página se declara en español para que no se ofrezca
// traducirla automáticamente (por ejemplo, «Cód.» se traducía como «Bacalao»).
if (Platform.OS === "web" && typeof document !== "undefined")
  document.documentElement.lang = "es-MX";

// El progreso de descarga no vuelve a renderizar las pantallas del negocio.
const StableAppContent = React.memo(AppContent);

export default function AluformixApp({ audience }) {
  const update = useAppUpdates();
  if (!useAppFonts()) return null;
  return (
    <SafeAreaProvider>
      <View style={{ flex: 1 }}>
        <StableAppContent audience={audience} />
        <UpdateStatus update={update} />
      </View>
    </SafeAreaProvider>
  );
}

function AppContent({ audience }) {
  const storage = useMemo(() => createSessionStorage(audience), [audience]);
  // Modo oscuro: preferencia de cada persona, guardada en el dispositivo.
  const [dark, setDark] = useState(false);
  useEffect(() => {
    let active = true;
    loadDarkMode(audience).then((value) => active && setDark(value));
    return () => {
      active = false;
    };
  }, [audience]);
  const changeDarkMode = (value) => {
    setDark(value);
    saveDarkMode(audience, value);
  };
  const offlineStore = useMemo(() => createOfflineStore(audience), [audience]);
  const client = useMemo(
    () =>
      demo
        ? createDemoClient(audience)
        : withOfflineData(
            createFirebaseClient({
              audience,
              storage,
              forceLongPolling: Platform.OS === "android",
              getAssistantAppCheckToken,
              config: {
                projectId: "alumineroapp-9244c",
                apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY,
                appId: process.env.EXPO_PUBLIC_FIREBASE_APP_ID,
              },
            }),
            offlineStore,
            async () => {
              const network = await Network.getNetworkStateAsync();
              return canAttemptNetwork(network);
            },
          ),
    [storage, audience, offlineStore],
  );
  const [offline, setOffline] = useState(false);
  useEffect(() => {
    let active = true;
    const refresh = async () => {
      const network = await Network.getNetworkStateAsync();
      if (!active) return;
      const connected = canAttemptNetwork(network);
      setOffline(!connected);
      if (connected) void client.syncOffline?.().catch(() => {});
    };
    void refresh().catch(() => {});
    const network = Network.addNetworkStateListener(
      () => void refresh().catch(() => {}),
    );
    const foreground = AppState.addEventListener("change", (state) => {
      if (state === "active") void refresh().catch(() => {});
    });
    return () => {
      active = false;
      network.remove();
      foreground.remove();
    };
  }, [client]);
  const [user, setUser] = useState(null),
    [mode, setMode] = useState("login"),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState(""),
    [issue, setIssue] = useState(null);
  const [values, setValues] = useState({}),
    [show, setShow] = useState(false);
  const working = useRef(false),
    mounted = useRef(true);
  const change = (name, value) => {
    setValues((previous) => ({ ...previous, [name]: value }));
    setIssue((previous) => (previous?.field === name ? null : previous));
  };
  function switchMode(next) {
    setMode(next);
    setValues({});
    setShow(false);
    setMessage("");
    setIssue(null);
  }
  async function run(action, { resetFeedback = true, blocking = true } = {}) {
    if (blocking && working.current) return;
    if (blocking) {
      working.current = true;
      setBusy(true);
    }
    if (resetFeedback) {
      setMessage("");
      setIssue(null);
    }
    try {
      await action();
    } catch (error) {
      if (mounted.current) {
        const message = error.message ?? "No fue posible continuar.";
        setIssue({ message, field: error.field ?? null });
        if (resetFeedback) Keyboard.dismiss();
        if (error.status === 401 && user) {
          setUser(null);
          setMode("login");
        }
      }
    } finally {
      if (blocking) {
        working.current = false;
        if (mounted.current) setBusy(false);
      }
    }
  }
  useEffect(() => {
    mounted.current = true;
    run(async () => setUser(await client.current(audience)));
    const listener = AppState.addEventListener("change", (state) => {
      if (state !== "active") {
        setValues((previous) => ({
          ...previous,
          password: "",
          confirmation: "",
          currentPassword: "",
          token: "",
          setupKey: "",
        }));
        setShow(false);
        return;
      }
      run(
        async () => {
          const current = await client.current(audience);
          setUser(current);
          if (!current)
            setMode((previous) => (previous === "change" ? "login" : previous));
        },
        { resetFeedback: false },
      );
    });
    return () => {
      mounted.current = false;
      listener.remove();
    };
  }, [client, audience]);
  async function submit() {
    await run(async () => {
      const password = values.password ?? "";
      if (mode === "register") {
        if (
          audience === "empresa" &&
          !/^[a-f0-9]{32}$/.test(values.inviteCode?.trim().toLowerCase() ?? "")
        )
          throw formError(
            "inviteCode",
            "Ingresa el código de invitación de Empresa.",
          );
        if (!values.name?.trim())
          throw formError("name", "Escribe tu nombre completo.");
        const phone = values.phone?.trim() ?? "";
        if (
          !/^[0-9 +()\-]+$/.test(phone) ||
          !/^\d{10,15}$/.test(phone.replace(/\D/g, ""))
        )
          throw formError("phone", "Escribe un teléfono de 10 a 15 dígitos.");
      }
      if (
        ["login", "register", "setup", "forgot"].includes(mode) &&
        !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/u.test(values.email?.trim() ?? "")
      )
        throw formError(
          "email",
          "Escribe un correo válido, como nombre@gmail.com.",
        );
      if (mode === "change" && !values.currentPassword)
        throw formError("currentPassword", "Escribe tu contraseña actual.");
      if (
        mode === "reset" &&
        !/^[a-f0-9]{64}$/i.test(values.token?.trim() ?? "")
      )
        throw formError(
          "token",
          "Copia el código completo del correo de recuperación.",
        );
      if (["register", "setup", "reset", "change"].includes(mode)) {
        if (password.length < 12 || password.length > 128)
          throw formError(
            "password",
            "Usa una contraseña de 12 a 128 caracteres.",
          );
        if (password !== values.confirmation)
          throw formError("confirmation", "Las contraseñas no coinciden.");
      }
      if (mode === "login") {
        if (!password) throw formError("password", "Escribe tu contraseña.");
        const account = await client.login(values.email, password, audience);
        setValues({});
        setUser(account);
      } else if (mode === "register") {
        await client.register({
          name: values.name ?? "",
          phone: values.phone ?? "",
          inviteCode: values.inviteCode,
          email: values.email ?? "",
          password,
        });
        switchMode("login");
        setMessage("Cuenta creada. Inicia sesión.");
      } else if (mode === "setup") {
        const key = values.setupKey?.trim() ?? "";
        if (key.length < 32)
          throw formError(
            "setupKey",
            "Ingresa el código de activación de Empresa.",
          );
        await client.setupAdmin({ email: values.email, password }, key);
        switchMode("login");
        setMessage("Cuenta administradora creada. Inicia sesión.");
      } else if (mode === "forgot") {
        await client.recovery(values.email ?? "");
        switchMode(client.cloud ? "login" : "reset");
        setMessage(
          "Si la cuenta existe y el servicio está disponible, recibirás instrucciones por correo.",
        );
      } else if (mode === "reset") {
        await client.reset(values.token.trim(), password);
        switchMode("login");
        setMessage("Contraseña actualizada. Inicia sesión.");
      } else if (mode === "change") {
        await client.changePassword(values.currentPassword ?? "", password);
        setUser(null);
        switchMode("login");
        setMessage(
          "Contraseña actualizada. Las sesiones anteriores se cerraron.",
        );
      }
    });
  }
  function field(
    name,
    placeholder,
    { secret = false, keyboard = "default", maxLength = 128 } = {},
  ) {
    return (
      <View key={name}>
        <TextInput
          accessibilityLabel={placeholder}
          placeholder={placeholder}
          placeholderTextColor="#657b91"
          value={values[name] ?? ""}
          onChangeText={(value) => change(name, value)}
          secureTextEntry={secret && !show}
          autoCapitalize={
            secret || keyboard === "email-address" ? "none" : "sentences"
          }
          autoCorrect={!secret && keyboard === "default"}
          keyboardType={keyboard}
          maxLength={maxLength}
          editable={!busy}
          style={[
            styles.input,
            issue?.field === name && validationStyles.invalid,
          ]}
        />
        <FieldIssue message={issue?.field === name ? issue.message : null} />
      </View>
    );
  }
  function button(label, action, secondary = false) {
    return (
      <Pressable
        key={label}
        accessibilityRole="button"
        disabled={busy}
        onPress={action}
        style={[
          styles.button,
          secondary && styles.secondary,
          busy && styles.disabled,
        ]}
      >
        <Text style={[styles.buttonText, secondary && styles.secondaryText]}>
          {label}
        </Text>
      </Pressable>
    );
  }
  async function logout(all) {
    await run(async () => {
      try {
        await client.logout(all);
        setMessage("Sesión cerrada.");
      } finally {
        setUser(null);
        setValues({});
        setMode("login");
      }
    });
  }
  const title = {
    login: "Inicia sesión",
    register: "Crea tu cuenta",
    setup: "Crea el primer administrador",
    forgot: "Recupera tu acceso",
    reset: "Nueva contraseña",
    change: "Cambia tu contraseña",
  }[mode];
  if (user && mode !== "change") {
    return (
      <SafeAreaView
        style={[styles.businessScreen, dark && styles.businessScreenDark]}
      >
        <StatusBar style={dark ? "light" : "dark"} />
        {offline && (
          <Text
            accessibilityLiveRegion="polite"
            style={{
              backgroundColor: "#fff4d6",
              color: "#573d00",
              padding: 10,
            }}
          >
            {audience === "empresa"
              ? "Sin conexión. Mostramos los datos descargados. Conéctate para guardar cambios de administración."
              : "Sin conexión. Mostramos los datos descargados. Los encargos pendientes se enviarán al recuperar internet."}
          </Text>
        )}
        <BusinessApp
          key={user.id}
          client={client}
          user={user}
          dark={dark}
          onDarkMode={changeDarkMode}
          audience={audience}
          busy={busy}
          run={run}
          message={message}
          issue={issue}
          onDismissIssue={() => setIssue(null)}
          onPassword={demo ? undefined : () => switchMode("change")}
          onLogout={logout}
          onUser={setUser}
        />
      </SafeAreaView>
    );
  }
  return (
    <SafeAreaView style={styles.screen}>
      <KeyboardAvoidingView
        style={styles.screen}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <StatusBar style="dark" />
        <ScrollView
          contentContainerStyle={styles.container}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.brand}>
            <Image
              source={require("../assets/aluformix-logo.png")}
              style={styles.brandImage}
            />
            <View>
              <Text style={styles.logo}>ALUFORMIX</Text>
              <Text style={styles.subtitle}>
                {audience === "empresa" ? "EMPRESA" : "CLIENTE"}
              </Text>
            </View>
          </View>
          {demo && (
            <Text accessibilityRole="text" style={styles.demo}>
              Modo demostración: usa una cuenta de ejemplo. El registro real se
              guarda desde la app conectada.
            </Text>
          )}
          {demo ? (
            <View style={styles.card}>
              <Text style={styles.title}>Explora Aluformix</Text>
              {button("Entrar a la demostración", () =>
                run(async () => setUser(await client.enterDemo())),
              )}
            </View>
          ) : (
            <View style={styles.card}>
              <Text style={styles.title}>{title}</Text>
              {mode === "register" &&
                field("name", "Nombre completo", { maxLength: 120 })}
              {mode === "register" &&
                field("phone", "Teléfono", {
                  keyboard: "phone-pad",
                  maxLength: 25,
                })}
              {["login", "register", "setup", "forgot"].includes(mode) &&
                field("email", "Correo electrónico", {
                  keyboard: "email-address",
                  maxLength: 254,
                })}
              {mode === "register" &&
                audience === "empresa" &&
                field("inviteCode", "Código de invitación de Empresa", {
                  secret: true,
                  maxLength: 32,
                })}
              {mode === "setup" &&
                field("setupKey", "Código de activación de Empresa", {
                  secret: true,
                  maxLength: 256,
                })}
              {mode === "reset" &&
                field("token", "Código de recuperación", {
                  secret: true,
                  maxLength: 64,
                })}
              {mode === "change" &&
                field("currentPassword", "Contraseña actual", { secret: true })}
              {mode !== "forgot" &&
                field(
                  "password",
                  mode === "login" ? "Contraseña" : "Nueva contraseña",
                  { secret: true },
                )}
              {["register", "setup", "reset", "change"].includes(mode) &&
                field("confirmation", "Confirma la contraseña", {
                  secret: true,
                })}
              {mode !== "forgot" &&
                button(
                  show ? "Ocultar contraseña" : "Mostrar contraseña",
                  () => setShow(!show),
                  true,
                )}
              {button(
                mode === "forgot"
                  ? "Enviar instrucciones"
                  : mode === "register" || mode === "setup"
                    ? "Crear cuenta"
                    : mode === "login"
                      ? "Iniciar sesión"
                      : "Guardar contraseña",
                submit,
              )}
              {mode === "login" &&
                (audience === "cliente" || client.cloud) &&
                button(
                  audience === "empresa"
                    ? "Crear cuenta de Empresa"
                    : "Crear cuenta de comprador",
                  () => switchMode("register"),
                  true,
                )}
              {mode === "login" &&
                audience === "empresa" &&
                !client.cloud &&
                button(
                  "Crear primer administrador",
                  () => switchMode("setup"),
                  true,
                )}
              {mode === "login" &&
                button(
                  "Olvidé mi contraseña",
                  () => switchMode("forgot"),
                  true,
                )}
              {mode === "forgot" &&
                !client.cloud &&
                button("Ya tengo un código", () => switchMode("reset"), true)}
              {mode !== "login" &&
                button(
                  mode === "change" ? "Volver a mi cuenta" : "Volver al acceso",
                  () => switchMode("login"),
                  true,
                )}
            </View>
          )}
          {busy && <ActivityIndicator size="large" color="#007bff" />}
          {!!message && (
            <Text accessibilityLiveRegion="polite" style={styles.message}>
              {message}
            </Text>
          )}
        </ScrollView>
        <Notice issue={issue} onDismiss={() => setIssue(null)} />
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f2f6fb" },
  businessScreen: { flex: 1, backgroundColor: "#f2f6fb" },
  businessScreenDark: { backgroundColor: "#000000" },
  brand: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginBottom: 9,
  },
  brandImage: { width: 44, height: 44, borderRadius: 22 },
  container: {
    padding: 24,
    paddingTop: 28,
    paddingBottom: 48,
    width: "100%",
    // En el navegador de la PC se limita al ancho de un teléfono.
    maxWidth: Platform.OS === "web" ? 430 : 600,
    alignSelf: "center",
    gap: 14,
  },
  logo: { fontSize: 25, fontWeight: "800", color: "#07325a" },
  subtitle: {
    color: "#526b82",
    fontSize: 10,
    letterSpacing: 1.6,
    fontWeight: "800",
  },
  title: {
    fontSize: 27,
    fontWeight: "700",
    color: "#102c46",
    marginBottom: 16,
  },
  card: {
    backgroundColor: "#fff",
    padding: 18,
    borderRadius: 16,
    gap: 12,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: "#dce7f2",
  },
  input: {
    backgroundColor: "#fff",
    borderColor: "#bdcee0",
    borderWidth: 1,
    borderRadius: 10,
    padding: 14,
    fontSize: 16,
    color: "#102c46",
    minHeight: 52,
  },
  button: {
    backgroundColor: "#007bff",
    borderRadius: 12,
    padding: 14,
    alignItems: "center",
    marginVertical: 4,
  },
  secondary: { backgroundColor: "#e8f2ff" },
  buttonText: { color: "#fff", fontWeight: "700", fontSize: 15 },
  secondaryText: { color: "#0066cc" },
  disabled: { opacity: 0.5 },
  message: { color: "#334f68", fontSize: 15, lineHeight: 22 },
  name: { fontSize: 19, fontWeight: "700", color: "#102c46" },
  navigation: { marginVertical: 12 },
  empty: { paddingVertical: 24, color: "#526b82" },
  demo: {
    backgroundColor: "#fff6e0",
    borderColor: "#f1dca4",
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    color: "#6b4e00",
    fontSize: 14,
    lineHeight: 20,
  },
});
