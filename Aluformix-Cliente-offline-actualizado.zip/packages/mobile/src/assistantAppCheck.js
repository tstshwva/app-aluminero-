export const getAssistantAppCheckToken = undefined;
