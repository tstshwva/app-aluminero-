import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";
import { transformSync } from "@babel/core";
import React, { act } from "react";
import Renderer from "react-test-renderer";
const require = createRequire(import.meta.url);
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
async function mount() {
  let source = await readFile("packages/mobile/src/Scanner.js", "utf8");
  source = source
    .replace(
      /import\s*\{[^}]*\}\s*from "\.\/localTextReader";/,
      `const localTextAvailable=true,readLocalText=async uri=>{if(uri!=="file:///hoja.jpg")throw Error("URI incorrecta");return "2 rieles\\nAdaptador XX";};`,
    )
    .replace(
      'from "react";',
      () => 'from "' + pathToFileURL(require.resolve("react")).href + '";',
    )
    .replace(
      /import \{[^}]*\} from "react-native";/,
      'const Image="Image",Linking={},Pressable="Pressable",View="View";',
    )
    .replace(
      /import \{[^}]*\} from ".\/Typography";/,
      'const Text="Text",TextInput="TextInput";',
    )
    .replace(
      /import \{[^}]*\} from "expo-camera";/,
      'const CameraView="CameraView",useCameraPermissions=()=>[{granted:true}];',
    )
    .replace('import { Notice } from "./Feedback";', 'const Notice="Notice";')
    .replace(/require\("\.\.\/assets\/[^"]+"\)/g, "0");
  const code = transformSync(source, {
    babelrc: false,
    configFile: false,
    plugins: ["@babel/plugin-transform-react-jsx"],
  }).code;
  const Scanner = (
    await import(
      "data:text/javascript;base64," + Buffer.from(code).toString("base64")
    )
  ).default;
  let tree,
    submitted = [];
  await act(async () => {
    tree = Renderer.create(
      React.createElement(Scanner, {
        onList: (value) => submitted.push(value),
      }),
      {
        createNodeMock: (node) =>
          node.type === "CameraView"
            ? {
                takePictureAsync: async (options) => {
                  assert.equal(options.base64, false);
                  assert.equal(options.quality, 1);
                  return { uri: "file:///hoja.jpg" };
                },
              }
            : null,
      },
    );
  });
  const press = async (label) => {
    await act(async () => {
      await tree.root
        .findAllByType("Pressable")
        .find((node) =>
          node
            .findAllByType("Text")
            .some((text) => text.props.children === label),
        )
        .props.onPress();
    });
  };
  return {
    tree,
    press,
    submitted,
    close: () => act(async () => tree.unmount()),
  };
}
test("La foto se procesa localmente a máxima calidad y no se envía a internet", async () => {
  const s = await mount();
  await s.press("Fotografiar hoja escrita");
  assert.deepEqual(s.submitted, []);
  assert.equal(
    s.tree.root.findByType("TextInput").props.value,
    "2 rieles\nAdaptador XX",
  );
  assert.equal(
    s.tree.root
      .findAllByType("Text")
      .some((node) => String(node.props.children).includes("usa internet")),
    false,
  );
  await s.press("Buscar materiales de la lista");
  assert.deepEqual(s.submitted, ["2 rieles\nAdaptador XX"]);
  await s.close();
});
