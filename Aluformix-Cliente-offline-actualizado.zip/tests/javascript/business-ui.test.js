import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";
import path from "node:path";
import { transformSync } from "@babel/core";
import React, { act } from "react";
import TestRenderer from "react-test-renderer";
const require = createRequire(import.meta.url);
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
async function component() {
  let source = await readFile("packages/mobile/src/BusinessApp.js", "utf8");
  source = source
    .replace(/import \{[^}]*\} from "\.\/Typography";/, "")
    .replace(
      'import AssistantChat from "./AssistantChat";',
      "const AssistantChat=()=>null;",
    )
    .replace(
      'import { useOrderOutbox } from "./orderOutbox";',
      "const useOrderOutbox=()=>({});",
    )
    .replace(/require\("\.\.\/assets\/[^"\n]+\.(png|jpg|webp)"\)/g, "0")
    .replace(
      'import { FieldIssue, formError, Notice, validationStyles } from "./Feedback";',
      "const FieldIssue=({message})=>message,Notice=({issue})=>issue?.message??null,validationStyles={invalid:{borderColor:'red'}},formError=(field,message)=>Object.assign(new Error(message),{field});",
    )
    .replace(
      '"./measure.js"',
      JSON.stringify(
        pathToFileURL(path.resolve("packages/mobile/src/measure.js")).href,
      ),
    )
    .replace(
      /from ['"]react['"];/,
      `from '${pathToFileURL(require.resolve("react")).href}';`,
    )
    .replace(
      /import\s*\{[^}]*\}\s*from ['"]react-native['"];/s,
      `const Animated={ScrollView:'ScrollView',View:'View',event:()=>()=>{},Value:class{interpolate(){return 0}setValue(){}},timing:()=>({start(){},stop(){}})},Easing={out:()=>null,cubic:null},Platform={OS:'web'},Alert={alert:(title,message,buttons)=>buttons?.at(-1)?.onPress?.()},AppState={addEventListener:()=>({remove(){}})},ActivityIndicator='ActivityIndicator',ScrollView='ScrollView',Image='Image',Pressable='Pressable',Share={share:async()=>{}},StyleSheet={create:x=>x},Text='Text',TextInput='TextInput',View='View',useWindowDimensions=()=>({width:globalThis.__uiWidth??390,height:800});`,
    )
    .replace(
      /import\s*\{[^}]*\}\s*from ['"].\/catalogImages['"];/,
      "const catalogImages=globalThis.__catalogImages??{},genericImages={},systemImages={};",
    )
    .replace(
      /from ['"]@aluformix\/catalog['"];/,
      `from '${pathToFileURL(path.resolve("packages/catalog/src/index.js")).href}';`,
    )
    .replace(
      /import\s*\{\s*randomUUID\s*\}\s*from ['"]expo-crypto['"];/,
      "import {randomUUID} from 'node:crypto';",
    )
    .replace(
      /import Scanner from ['"].\/Scanner['"];/,
      "const Scanner=()=>null;",
    )
    .replace(
      /import\s*\{[^}]*\}\s*from ['"].\/push['"];/,
      "const registerPush=async()=>{},disablePush=async()=>{};",
    )
    .replace(
      /import\s*\{[^}]*\}\s*from ['"].\/preferences['"];/,
      "const loadPushEnabled=async()=>false,savePushEnabled=async()=>{},loadContact=async()=>({}),saveContact=async(id,c)=>{globalThis.__savedContact=[id,c]};",
    );
  const code = transformSync(source, {
    babelrc: false,
    configFile: false,
    plugins: ["@babel/plugin-transform-react-jsx"],
  }).code;
  return (
    await import(
      "data:text/javascript;base64," + Buffer.from(code).toString("base64")
    )
  ).default;
}
test("Pantallas del comprador conectan catálogo, carrito, solicitud y aceptación de cotización", async () => {
  const BusinessApp = await component(),
    calls = [];
  let accepted = false;
  const product = {
    id: "10",
    category_id: 1,
    code: "P-10",
    name: "Perfil de prueba UI",
    unit: "barra",
    finish: "Natural, Negro",
    price: "400.00",
    length_mm: 6000,
    active: 1,
    available: "10.000",
  };
  const detail = () => ({
    order: {
      id: "20",
      customer_name: "Comprador",
      customer_phone: "9991234567",
      status: accepted ? "Confirmado" : "Cotizado",
      fulfillment: "Recoger",
    },
    items: [
      {
        id: "30",
        product_id: "10",
        product_code: product.code,
        product_name: product.name,
        quantity: "1.000",
        finish: "Negro",
        cut_length_mm: 1255,
        unit_price: "400.00",
      },
    ],
    quote: {
      id: "40",
      revision: 2,
      status: accepted ? "Aceptada" : "Enviada",
      subtotal: "400.00",
      tax_rate: "0.1600",
      tax: "64.00",
      shipping: "0.00",
      total: "464.00",
      paid: "0.00",
      balance: "464.00",
    },
    payments: [],
    history: [],
  });
  const client = {
    company: async () => ({ name: "Empresa", address: "Sucursal" }),
    products: async () => [product],
    categories: async () => [{ id: 1, name: "Perfiles" }],
    product: async () => product,
    profile: async () => ({
      name: "Comprador",
      phone: "9991234567",
      email: "buyer@example.invalid",
      address: "Calle 1 #2, Centro",
    }),
    cloud: true,
    saveProfile: async () => {
      throw new Error("La regla aún no está publicada");
    },
    createOrder: async (body) => {
      calls.push(body);
      return { id: "20" };
    },
    order: async () => detail(),
    acceptQuote: async (orderId, revision) => {
      calls.push({ orderId, revision });
      accepted = true;
    },
  };
  let renderer;
  const run = async (action) => action();
  await act(async () => {
    renderer = TestRenderer.create(
      React.createElement(BusinessApp, {
        client,
        user: { id: "1", name: "Comprador", role: "Cliente" },
        audience: "cliente",
        busy: false,
        run,
        onUser() {},
        onPassword() {},
        onLogout() {},
      }),
    );
  });
  async function press(label) {
    const node = renderer.root.findAll(
      (n) =>
        n.type === "Pressable" &&
        (n.props.accessibilityLabel === label ||
          n.findAll((x) => x.type === "Text" && x.children.join("") === label)
            .length > 0),
    )[0];
    assert.ok(node, "Botón disponible: " + label);
    await act(async () => {
      await node.props.onPress();
    });
  }
  const tabs = () =>
    renderer.root.findAll(
      (n) => n.type === "Pressable" && n.props.accessibilityRole === "tab",
    );
  assert.deepEqual(
    tabs().map((tab) => tab.props.accessibilityLabel),
    ["Inicio", "Catálogo", "Encargos", "Perfil"],
  );
  await press("Explorar catálogo");
  assert.equal(
    tabs().find((tab) => tab.props.accessibilityState.selected)?.props
      .accessibilityLabel,
    "Catálogo",
  );
  await press("Ver P-10");
  const lengthInput = (unit) =>
    renderer.root.findByProps({
      accessibilityLabel: "Longitud del corte (opcional) (" + unit + ")",
    });
  await act(async () => lengthInput("cm").props.onChangeText("601"));
  await assert.rejects(
    () => press("Agregar al encargo"),
    (e) => e.field === "cutLengthMm" && /6 m/.test(e.message),
  );
  await act(async () => lengthInput("cm").props.onChangeText("125,5"));
  await press("Negro");
  await press("Longitud del corte (opcional) en m");
  assert.equal(lengthInput("m").props.value, "1.255");
  await press("Agregar al encargo");
  await press("Aumentar Perfil de prueba UI");
  assert.ok(
    renderer.root.findAll(
      (n) => n.type === "Text" && n.children.join("") === "$800.00",
    ).length,
  );
  await press("Reducir Perfil de prueba UI");
  // En 1, el botón − no debe bajar a 0.001.
  await press("Reducir Perfil de prueba UI");
  assert.equal(
    renderer.root.findByProps({
      accessibilityLabel: "Cantidad de Perfil de prueba UI",
    }).props.value,
    "1",
  );
  await press("Revisar solicitud");
  // Al pedir entrega se propone la dirección guardada en el perfil.
  await press("Solicitar entrega");
  assert.equal(
    renderer.root.findByProps({ placeholder: "Dirección completa" }).props
      .value,
    "Calle 1 #2, Centro",
  );
  await press("Recoger en sucursal");
  // Los datos de contacto se llenan en el mismo encargo.
  const contact = (label) =>
    renderer.root.findByProps({ accessibilityLabel: label });
  assert.equal(contact("Nombre o contacto").props.value, "Comprador");
  await act(async () => contact("Teléfono de contacto").props.onChangeText(""));
  await assert.rejects(
    () => press("Enviar solicitud"),
    (e) => e.field === "contactPhone",
  );
  assert.equal(calls.length, 0, "Sin teléfono no se envía");
  await act(async () =>
    contact("Teléfono de contacto").props.onChangeText("999 222 3344"),
  );
  await act(async () =>
    contact("Taller o negocio (opcional)").props.onChangeText("Taller Uno"),
  );
  await press("Enviar solicitud");
  assert.equal(
    calls[0].notes,
    "Contacto: Comprador\nTeléfono: 999 222 3344\nTaller: Taller Uno",
  );
  assert.deepEqual(globalThis.__savedContact, [
    "1",
    {
      name: "Comprador",
      phone: "999 222 3344",
      businessName: "Taller Uno",
      address: "Calle 1 #2, Centro",
    },
  ]);
  assert.equal(calls[0].items[0].productId, "10");
  assert.equal(calls[0].items[0].quantity, "1");
  assert.equal(calls[0].items[0].cutLengthMm, 1255);
  assert.equal(calls[0].items[0].finish, "Negro");
  assert.match(calls[0].requestKey, /^[a-f0-9-]{36}$/i);
  await press("Ver seguimiento");
  await press("Ver cotización");
  // Las líneas de la cotización llevan color del tema (en oscuro eran invisibles).
  const quoteLine = renderer.root.find(
    (n) =>
      n.type === "Text" &&
      n.children.join("").includes("× Perfil de prueba UI"),
  );
  assert.ok(
    [quoteLine.props.style].flat(Infinity).some((style) => style?.color),
    "La línea de la cotización debe tener color de texto",
  );
  await press("Aceptar cotización y reservar material");
  assert.deepEqual(calls[1], { orderId: "20", revision: 2 });
  assert.ok(
    renderer.root.findAll(
      (n) => n.type === "Text" && n.children.join("") === "Confirmado",
    ).length,
  );
  await press("Repetir como nuevo encargo");
  await press("Revisar solicitud");
  assert.ok(
    renderer.root.findAll(
      (n) => n.type === "Text" && n.children.join("") === "Negro · 1.255 m",
    ).length,
  );
  await press("Enviar solicitud");
  assert.equal(calls[2].items[0].finish, "Negro");
  assert.equal(calls[2].items[0].cutLengthMm, 1255);
  assert.notEqual(calls[2].requestKey, calls[0].requestKey);
  await act(async () => renderer.unmount());
});
test("Empresa puede cotizar y avanzar un encargo sin cuenta; operador no ve creación de personal", async () => {
  const BusinessApp = await component(),
    calls = [];
  let state = "Solicitado";
  const client = {
    dashboard: async () => ({ orders: [], lowStock: [] }),
    company: async () => ({ tax_rate: "0.1600" }),
    orders: async () => [{ id: "20", customer_name: "Cliente", status: state }],
    order: async () => ({
      order: {
        id: "20",
        user_id: null,
        customer_name: "Cliente",
        status: state,
        fulfillment: "Recoger",
      },
      items: [
        {
          id: "30",
          product_id: "10",
          product_name: "Perfil",
          product_code: "P-10",
          quantity: "1.000",
          unit_price: "400.00",
        },
      ],
      quote:
        state === "Solicitado"
          ? null
          : {
              revision: 1,
              tax_rate: "0.1600",
              shipping: "0.00",
              subtotal: "400.00",
              tax: "64.00",
              total: "464.00",
              paid: "0.00",
              balance: "464.00",
            },
      payments: [],
      history: [],
    }),
    quote: async (id, body) => {
      calls.push({ operation: "quote", id, body });
      state = "Cotizado";
    },
    acceptQuote: async (id, revision) => {
      calls.push({ operation: "accept", id, revision });
      state = "Confirmado";
    },
    orderStatus: async (id, status) => {
      calls.push({ operation: "status", id, status });
      state = status;
    },
  };
  let renderer;
  await act(async () => {
    renderer = TestRenderer.create(
      React.createElement(BusinessApp, {
        client,
        user: { id: "2", name: "Operador", role: "Operador" },
        audience: "empresa",
        busy: false,
        run: async (action) => action(),
        onUser() {},
        onPassword() {},
        onLogout() {},
      }),
    );
  });
  const buttons = (label) =>
    renderer.root.findAll(
      (n) =>
        n.type === "Pressable" &&
        (n.props.accessibilityLabel === label ||
          n.findAll((x) => x.type === "Text" && x.children.join("") === label)
            .length > 0),
    );
  async function press(label) {
    assert.ok(buttons(label).length, "Botón disponible: " + label);
    await act(async () => {
      await buttons(label)[0].props.onPress();
    });
  }
  const tabs = () =>
    renderer.root.findAll(
      (n) => n.type === "Pressable" && n.props.accessibilityRole === "tab",
    );
  assert.deepEqual(
    tabs().map((tab) => tab.props.accessibilityLabel),
    ["Inicio", "Inventario", "Encargos", "Más"],
  );
  await press("Más");
  assert.equal(
    tabs().find((tab) => tab.props.accessibilityState.selected)?.props
      .accessibilityLabel,
    "Más",
  );
  assert.equal(buttons("Usuarios y permisos").length, 0);
  await press("Inicio");
  await press("Revisar encargos");
  await press("Ver detalle y seguimiento");
  // El impuesto se muestra como porcentaje y se envía como tasa.
  assert.equal(
    renderer.root.findByProps({ accessibilityLabel: "Impuesto (%)" }).props
      .value,
    "16",
  );
  await press("Enviar cotización");
  assert.equal(calls[0].body.prices[0].unitPrice, "400.00");
  assert.equal(calls[0].body.taxRate, "0.1600");
  await press("Registrar aceptación del cliente sin cuenta");
  await press("Empezar preparación");
  await press("Marcar listo");
  await press("Registrar entrega");
  assert.equal(state, "Entregado");
  assert.equal(calls[1].revision, 1);
  await act(async () => renderer.unmount());
});
test("Catálogo: filtros, búsqueda, favoritos, ficha y encargo con acabado", async () => {
  const { default: data } = await import("../../packages/catalog/src/data.js");
  const { catalogRows } = await import("../../server/src/catalog-import.js");
  const categories = [],
    calls = [];
  const products = catalogRows(data.productos).map((r, i) => {
    let category = categories.find((c) => c.name === r.category);
    if (!category) {
      category = { id: categories.length + 1, name: r.category };
      categories.push(category);
    }
    return {
      id: String(i + 1),
      category_id: category.id,
      code: r.code,
      name: r.name,
      description: r.description,
      unit: r.unit,
      finish: r.finish,
      length_mm: r.lengthMm,
      price: r.price,
      image_url: null,
      active: 1,
      available: "0.000",
    };
  });
  const favorites = new Set(["1"]);
  const client = {
    products: async () => products,
    categories: async () => categories,
    favorites: async () => products.filter((p) => favorites.has(p.id)),
    favorite: async (id, enabled) => {
      calls.push({ favorite: id, enabled });
      if (enabled) favorites.add(String(id));
      else favorites.delete(String(id));
    },
    product: async (id) => products.find((p) => p.id === String(id)),
    company: async () => ({ tax_rate: "0.1600" }),
    profile: async () => ({ name: "Comprador", phone: "9991234567" }),
    createOrder: async (body) => {
      calls.push(body);
      return { id: "50" };
    },
  };
  globalThis.__uiWidth = 1200;
  const BusinessApp = await component();
  let renderer;
  await act(async () => {
    renderer = TestRenderer.create(
      React.createElement(BusinessApp, {
        client,
        user: { id: "1", name: "Comprador", role: "Cliente" },
        audience: "cliente",
        busy: false,
        run: async (action) => action(),
        onUser() {},
        onPassword() {},
        onLogout() {},
      }),
    );
  });
  const texts = () =>
    renderer.root
      .findAll((n) => n.type === "Text")
      .map((n) => n.children.join(""));
  const cards = () =>
    renderer.root
      .findAll(
        (n) =>
          n.type === "Pressable" &&
          /^Ver /.test(n.props.accessibilityLabel ?? ""),
      )
      .map((n) => n.props.accessibilityLabel.slice(4));
  async function press(label) {
    const node = renderer.root.findAll(
      (n) =>
        n.type === "Pressable" &&
        (n.props.accessibilityLabel === label ||
          n.findAll((x) => x.type === "Text" && x.children.join("") === label)
            .length > 0),
    )[0];
    assert.ok(node, "Botón disponible: " + label);
    await act(async () => {
      await node.props.onPress();
    });
  }
  async function type(label, value) {
    const input = renderer.root.find(
      (n) => n.type === "TextInput" && n.props.accessibilityLabel === label,
    );
    await act(async () => input.props.onChangeText(value));
  }
  const idOf = (code) => products.find((p) => p.code === code).id;
  const total = products.length;
  await press("Catálogo");
  assert.equal(cards().length, Math.min(20, total));
  while (cards().length < total) await press("Mostrar más materiales");
  assert.equal(cards().length, total);
  assert.ok(texts().includes(total + " productos"));
  assert.ok(!texts().some((t) => /$0.00/.test(t)), "Nunca muestra $0.00");
  assert.ok(texts().includes("Consultar precio"));
  assert.ok(
    !texts().some((t) => /53883 · Barra de 6 m/.test(t)),
    "Sin 6 m por defecto",
  );
  await press("Filtrar Perfiles");
  while (texts().includes("Mostrar más materiales"))
    await press("Mostrar más materiales");
  assert.equal(
    cards().length,
    data.productos.filter((p) => p.codigo && p.grupo === "Perfiles").length,
  );
  await press("Cancel de baño");
  assert.deepEqual(cards().sort(), ["10198", "1046", "11035", "11174"]);
  await press("Filtrar Herrajes");
  assert.equal(cards().length, 12);
  await press("Filtrar Sistemas");
  assert.equal(cards().filter((c) => c.startsWith("sistema ")).length, 8);
  await press("Ver sistema C-100 MID");
  assert.ok(texts().includes("Guía de armado C-100 MID"));
  assert.ok(texts().includes("Calculadora de cortes"));
  await type("Ancho total L (cm)", "200");
  await press("Alto total H en m");
  await type("Alto total H (m)", "1,5");
  await press("Calcular cortes");
  assert.ok(
    texts().some((t) => t.startsWith("862 × 1288 mm")),
    "Vidrio LF × HF según la tabla",
  );
  assert.ok(texts().some((t) => /certificación estructural/.test(t)));
  await press("Catálogo");
  await press("Filtrar Todos");
  await press("Vidrio");
  assert.deepEqual(cards().sort(), ["7013", "7014"]);
  await press("Vidrio");
  await type("Buscar producto", "2488");
  assert.deepEqual(cards(), ["2488"]);
  await type("Buscar producto", "07333");
  assert.deepEqual(cards(), ["07333"]);
  await type("Buscar producto", "pasamanos");
  assert.deepEqual(cards().sort(), ["53883", "53896"]);
  // Búsqueda por lista (un material por renglón): el contador cuenta lo mostrado.
  await type("Buscar producto", "2488\n07333");
  assert.deepEqual(cards().sort(), ["07333", "2488"]);
  assert.ok(
    texts().includes("2 productos para «2488, 07333»"),
    "El contador de la lista cuenta solo los productos mostrados",
  );
  await type("Buscar producto", "sin coincidencias xyz");
  assert.ok(texts().includes("No encontramos productos"));
  await press("Limpiar filtros");
  await press("♥ Favoritos");
  assert.deepEqual(cards(), [products[0].code]);
  await press("♥ Favoritos");
  await type("Buscar producto", "2488");
  await press("Agregar a favoritos 2488");
  assert.deepEqual(calls.at(-1), { favorite: idOf("2488"), enabled: true });
  assert.ok(
    renderer.root.findAll(
      (n) => n.props.accessibilityLabel === "Quitar de favoritos 2488",
    ).length,
  );
  await press("Ver 2488");
  assert.ok(texts().includes("Tubo cuadrado de 1 pulgada"));
  assert.ok(texts().includes("Código 2488"));
  assert.ok(texts().includes("25.4 × 25.4 mm"));
  assert.ok(texts().includes("Natural, Blanco, Negro"));
  assert.ok(texts().includes("Verificado con el plano"));
  assert.ok(texts().includes("AGREGAR A ENCARGO"));
  await assert.rejects(press("Agregar al encargo"), /acabado/);
  await press("Negro");
  await press("Agregar al encargo");
  await press("Revisar solicitud");
  await press("Enviar solicitud");
  assert.deepEqual(calls.at(-1).items, [
    {
      productId: idOf("2488"),
      quantity: "1",
      cutLengthMm: null,
      finish: "Negro",
    },
  ]);
  delete globalThis.__uiWidth;
  await act(async () => renderer.unmount());
});
test("Perfil: el interruptor de modo oscuro cambia el tema", async () => {
  const BusinessApp = await component();
  const changes = [];
  const client = {
    products: async () => [],
    categories: async () => [],
    profile: async () => ({ name: "Comprador", phone: "", address: "" }),
  };
  const props = (dark) => ({
    client,
    user: { id: "1", name: "Comprador", role: "Cliente", email: "c@x.mx" },
    audience: "cliente",
    busy: false,
    dark,
    onDarkMode: (value) => changes.push(value),
    run: async (action) => action(),
    onUser() {},
    onPassword() {},
    onLogout() {},
  });
  let renderer;
  await act(async () => {
    renderer = TestRenderer.create(
      React.createElement(BusinessApp, props(false)),
    );
  });
  const press = async (label) => {
    const node = renderer.root.findAll(
      (n) => n.type === "Pressable" && n.props.accessibilityLabel === label,
    )[0];
    assert.ok(node, "Botón disponible: " + label);
    await act(async () => node.props.onPress());
  };
  const shellColor = () =>
    renderer.root.findAll((n) => n.type === "View")[0].props.style
      .backgroundColor;
  assert.equal(shellColor(), "#f2f6fb");
  await press("Perfil");
  const toggle = () =>
    renderer.root.find(
      (n) =>
        n.type === "Pressable" && n.props.accessibilityLabel === "Modo oscuro",
    );
  assert.equal(toggle().props.accessibilityState.checked, false);
  await press("Modo oscuro");
  assert.deepEqual(changes, [true]);
  await act(async () =>
    renderer.update(React.createElement(BusinessApp, props(true))),
  );
  assert.equal(toggle().props.accessibilityState.checked, true);
  assert.equal(shellColor(), "#000000");
  await act(async () => renderer.unmount());
});

test("Empresa muestra administración y oculta las herramientas de compra del Cliente", async () => {
  const BusinessApp = await component();
  const product = {
    id: "p",
    category_id: "cat",
    code: "R1",
    name: "Riel",
    unit: "barra",
    finish: "Natural, Negro",
    price: "100.00",
    length_mm: 6000,
    active: 1,
    stock: 10,
    reserved: 0,
  };
  const client = {
    dashboard: async () => ({ orders: [], lowStock: [] }),
    orders: async () => [],
    products: async () => [product],
    categories: async () => [{ id: "cat", name: "Perfiles" }],
    product: async () => product,
  };
  let renderer;
  await act(async () => {
    renderer = TestRenderer.create(
      React.createElement(BusinessApp, {
        client,
        user: { id: "admin", name: "Empresa", role: "Administrador" },
        audience: "empresa",
        busy: false,
        run: async (action) => action(),
        onUser() {},
        onPassword() {},
        onLogout() {},
        onDismissIssue() {},
      }),
    );
  });
  const labels = () =>
    renderer.root.findAllByType("Pressable").map(
      (node) =>
        node.props.accessibilityLabel ??
        node
          .findAllByType("Text")
          .map((text) => text.children.join(""))
          .join(""),
    );
  const absent = () => {
    for (const label of [
      "Mi encargo",
      "Nuevo encargo",
      "Escanear cotización",
      "Chatea con tu asistente",
      "Asistente de materiales",
      "Agregar al encargo",
      "Repetir como nuevo encargo",
      "Mis favoritos",
    ])
      assert.ok(
        !labels().some((value) => value.startsWith(label)),
        "No debe aparecer en Empresa: " + label,
      );
  };
  const press = async (label) => {
    const node = renderer.root
      .findAllByType("Pressable")
      .find(
        (node) =>
          node.props.accessibilityLabel === label ||
          node
            .findAllByType("Text")
            .some((text) => text.children.join("") === label),
      );
    assert.ok(node, "Disponible: " + label);
    await act(async () => {
      await node.props.onPress();
    });
  };
  absent();
  assert.ok(labels().includes("Registrar producto"));
  await press("Inventario");
  await press("Ver R1");
  absent();
  assert.ok(labels().includes("Editar producto"));
  assert.ok(labels().includes("Registrar entrada"));
  assert.equal(
    renderer.root
      .findAllByType("TextInput")
      .filter(
        (node) => node.props.placeholder === "Cantidad de esta presentación",
      ).length,
    0,
  );
  await press("Más");
  absent();
  assert.ok(labels().some((value) => value.startsWith("Configuración")));
  await act(async () => renderer.unmount());
});
